package com.example.houserentappproject;

public class House {


    String name, number, type, rent, city;

    public String getName() {
        return name;
    }

    public String getNumber() {
        return number;
    }

    public String getType() {
        return type;
    }

    public String getRent() {
        return rent;
    }

    public String getCity() {
        return city;
    }
}
